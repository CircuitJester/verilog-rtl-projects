module tb_ripple_carry_adder_4bit;

reg [3:0] a;
reg [3:0] b;
reg cin;

wire [3:0] sum;
wire cout;

ripple_carry_adder_4bit dut (
    .a(a),
    .b(b),
    .cin(cin),
    .sum(sum),
    .cout(cout)
);

initial begin
    $dumpfile("rca4.vcd");
    $dumpvars(0, tb_ripple_carry_adder_4bit);

    a = 4'b0000; b = 4'b0000; cin = 1'b0; #10;
    a = 4'b0001; b = 4'b0001; cin = 1'b0; #10;
    a = 4'b0011; b = 4'b0010; cin = 1'b0; #10;
    a = 4'b0101; b = 4'b0011; cin = 1'b0; #10;
    a = 4'b1111; b = 4'b0001; cin = 1'b0; #10;

    $finish;
end

endmodule