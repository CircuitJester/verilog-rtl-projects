# AND Gate

## Simulation

```bash
iverilog -o sim/and_gate RTL/and_gate.v tb/tb_and_gate.v
```

```bash
vvp sim/and_gate
```

```bash
gtkwave waveforms/vcd/and_gate.vcd
```

## Synthesis

```bash
yosys synth/scripts/synth_and_gate.ys | tee reports/and_gate_synthesis.log

```


"similarly for each module"