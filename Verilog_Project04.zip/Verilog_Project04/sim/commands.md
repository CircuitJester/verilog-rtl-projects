# Verilog Project 04 - Commands

---

## Timer

### Simulation

```bash
iverilog -o sim/timer RTL/timer.v tb/tb_timer.v
vvp sim/timer
gtkwave timer.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_timer.ys \
| tee reports/timer_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## PWM Generator

### Simulation

```bash
iverilog -o sim/pwm_generator RTL/pwm_generator.v tb/tb_pwm_generator.v
vvp sim/pwm_generator
gtkwave pwm.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_pwm_generator.ys \
| tee reports/pwm_generator_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## FIFO

### Simulation

```bash
iverilog -o sim/fifo RTL/fifo.v tb/tb_fifo.v
vvp sim/fifo
gtkwave fifo.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_fifo.ys \
| tee reports/fifo_synthesis.log \
&& rm -f synth/schematics/*.dot
```