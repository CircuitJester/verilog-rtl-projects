# SPI Master Commands

## Simulation

### Compile

```bash
iverilog \
-o sim/spi_master \
RTL/spi_master.v \
RTL/spi_master_fsm.v \
RTL/spi_clock_generator.v \
RTL/spi_bit_counter.v \
RTL/spi_shift_register.v \
tb/tb_spi_master.v
```

### Run Simulation

```bash
vvp sim/spi_master
```

### Open GTKWave

```bash
gtkwave spi_master.vcd
```

---

## RTL Synthesis

```bash
yosys synth/scripts/synth_spi_master.ys \
| tee reports/spi_master_synthesis.log \
&& rm -f synth/schematics/*.dot
```