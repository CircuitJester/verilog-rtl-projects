# Verilog Project 03 - Commands

---

## Traffic Light FSM

### Simulation

```bash
iverilog -o sim/traffic_light_fsm RTL/traffic_light_fsm.v tb/tb_traffic_light_fsm.v

vvp sim/traffic_light_fsm

gtkwave traffic_light.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_traffic_light_fsm.ys \
| tee reports/traffic_light_fsm_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## Sequence Detector (1011)

### Simulation

```bash
iverilog -o sim/sequence_detector_1011 RTL/sequence_detector_1011.v tb/tb_sequence_detector_1011.v

vvp sim/sequence_detector_1011

gtkwave sequence_detector.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_sequence_detector_1011.ys \
| tee reports/sequence_detector_1011_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## Vending Machine FSM

### Simulation

```bash
iverilog -o sim/vending_machine_fsm RTL/vending_machine_fsm.v tb/tb_vending_machine_fsm.v

vvp sim/vending_machine_fsm

gtkwave vending_machine.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_vending_machine_fsm.ys \
| tee reports/vending_machine_fsm_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## UART Transmitter FSM

### Simulation

```bash
iverilog -o sim/uart_tx_fsm RTL/uart_tx_fsm.v tb/tb_uart_tx_fsm.v

vvp sim/uart_tx_fsm

gtkwave uart_tx.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_uart_tx_fsm.ys \
| tee reports/uart_tx_fsm_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## UART Receiver FSM

### Simulation

```bash
iverilog -o sim/uart_rx_fsm RTL/uart_rx_fsm.v tb/tb_uart_rx_fsm.v

vvp sim/uart_rx_fsm

gtkwave uart_rx.vcd
```

### RTL Synthesis

```bash
yosys synth/scripts/synth_uart_rx_fsm.ys \
| tee reports/uart_rx_fsm_synthesis.log \
&& rm -f synth/schematics/*.dot
```