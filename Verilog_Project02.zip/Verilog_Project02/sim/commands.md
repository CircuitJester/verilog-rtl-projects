# Verilog Project 02 - Commands

## D Flip-Flop

### Simulation

```bash
iverilog -o sim/d_flip_flop RTL/d_flip_flop.v tb/tb_d_flip_flop.v
vvp sim/d_flip_flop
gtkwave waveforms/dff.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_d_flip_flop.ys \
| tee reports/d_flip_flop_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## D Flip-Flop with Asynchronous Reset

### Simulation

```bash
iverilog -o sim/dff_async_reset RTL/dff_async_reset.v tb/tb_dff_async_reset.v
vvp sim/dff_async_reset
gtkwave waveforms/dff_async_reset.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_dff_async_reset.ys \
| tee reports/dff_async_reset_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## 4-bit Register

### Simulation

```bash
iverilog -o sim/register_4bit RTL/register_4bit.v tb/tb_register_4bit.v
vvp sim/register_4bit
gtkwave waveforms/register_4bit.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_register_4bit.ys \
| tee reports/register_4bit_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## 4-bit Shift Register

### Simulation

```bash
iverilog -o sim/shift_register_4bit RTL/shift_register_4bit.v tb/tb_shift_register_4bit.v
vvp sim/shift_register_4bit
gtkwave waveforms/shift_register_4bit.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_shift_register_4bit.ys \
| tee reports/shift_register_4bit_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## 4-bit Binary Counter

### Simulation

```bash
iverilog -o sim/binary_counter_4bit RTL/binary_counter_4bit.v tb/tb_binary_counter_4bit.v
vvp sim/binary_counter_4bit
gtkwave waveforms/binary_counter.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_binary_counter_4bit.ys \
| tee reports/binary_counter_4bit_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## 4-bit Up/Down Counter

### Simulation

```bash
iverilog -o sim/up_down_counter_4bit RTL/up_down_counter_4bit.v tb/tb_up_down_counter_4bit.v
vvp sim/up_down_counter_4bit
gtkwave waveforms/up_down_counter.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_up_down_counter_4bit.ys \
| tee reports/up_down_counter_4bit_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## 4-bit Ring Counter

### Simulation

```bash
iverilog -o sim/ring_counter_4bit RTL/ring_counter_4bit.v tb/tb_ring_counter_4bit.v
vvp sim/ring_counter_4bit
gtkwave waveforms/ring_counter.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_ring_counter_4bit.ys \
| tee reports/ring_counter_4bit_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## 4-bit Johnson Counter

### Simulation

```bash
iverilog -o sim/johnson_counter_4bit RTL/johnson_counter_4bit.v tb/tb_johnson_counter_4bit.v
vvp sim/johnson_counter_4bit
gtkwave waveforms/johnson_counter.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_johnson_counter_4bit.ys \
| tee reports/johnson_counter_4bit_synthesis.log \
&& rm -f synth/schematics/*.dot
```

---

## Clock Divider by 2

### Simulation

```bash
iverilog -o sim/clock_divider_by2 RTL/clock_divider_by2.v tb/tb_clock_divider_by2.v
vvp sim/clock_divider_by2
gtkwave waveforms/clock_divider.vcd
```

### Synthesis

```bash
yosys synth/scripts/synth_clock_divider_by2.ys \
| tee reports/clock_divider_by2_synthesis.log \
&& rm -f synth/schematics/*.dot
```